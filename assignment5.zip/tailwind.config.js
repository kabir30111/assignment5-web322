module.exports = {
    content: ["./views/**/*.ejs"],
    theme: {
        extend: {},
    },
    plugins: [],
};
